#!/usr/bin/env bash

function usage()
{
   cat << HEREDOC

   Usage: $programe [--conf CONF_DIR] [--port PORT]

   optional arguments:
     -h, --help           show this help message and exit
     -p, --port NUM       set api port  default is 8091
     -c, --conf CONF_DIR  set conf dir default is ./config/

HEREDOC
}

programe=$(basename $0)

CURDIR=$(cd $(dirname $0); pwd)
if [ -z $port ]; then
  port=8091
fi

if [ -z $conf ]; then
  conf=$CURDIR/config/
fi

OPTS=$(getopt -o "hcp" --long "help,conf,port" -n "$programe" -- "$@")
if [ $? != 0 ] ; then echo "Error in command line arguments." >&2 ; usage; exit 1 ; fi

while true; do
  case "$1" in
    -h | --help ) usage; exit; ;;
    -p | --port ) port="$2"; shift 2 ;;
    -c | --conf ) conf="$2"; shift 2 ;;
    -- ) shift; break ;;
    * ) break ;;
  esac
done





RUNTIME_OUT_ROOT=$CURDIR/

export CGO_LDFLAGS="-L$RUNTIME_OUT_ROOT"
export LD_LIBRARY_PATH="$RUNTIME_OUT_ROOT"
export GIN_MODE=release

PY_INIT_SUCCESS="py/.success"

function init_plugin() {
  echo "Init Python Plugin Runtime Environment"
  rm -rf $CURDIR/py/pypy
  tar -xf $CURDIR/py/download/pypy3.7-v7.3.5-linux64.tar.bz2 -C $CURDIR/py/
  $CURDIR/py/pypy3.7-v7.3.5-linux64/bin/pypy3 -m venv $CURDIR/py/pypy
  . $CURDIR/py/pypy/bin/activate
  cat $CURDIR/py/requirements.txt |grep -v gevent|grep -v cffi|grep -v greenlet|grep -v readline > $CURDIR/py/tmp_requirements.txt
  pip install --no-index --find-links=$CURDIR/py/download -r $CURDIR/py/tmp_requirements.txt
  pip install $CURDIR/py/download/gevent-21.1.2.tar.gz
  cd ..
  touch $CURDIR/$PY_INIT_SUCCESS
  echo $CURDIR > $CURDIR/$PY_INIT_SUCCESS
  
}

if [ ! -f "$CURDIR/$PY_INIT_SUCCESS" ]; then
  init_plugin
fi

CUR_PY_DIR=$(cat $CURDIR/$PY_INIT_SUCCESS)
if [ "$CURDIR" != "$CUR_PY_DIR" ]; then
  init_plugin
fi

rm /dev/shm/elkeid_queue_community_*_req.shm > /dev/null 2>&1
rm /dev/shm/elkeid_queue_community_*_resp.shm > /dev/null 2>&1
sedStr="s|HUB_LOG_PATH: .*|HUB_LOG_PATH: $CURDIR/log/smith.log|g"
sed -in "$sedStr" $conf/smith.yml
export ELKEID_PLUGIN_PATH=$CURDIR/py
$CURDIR/bin/elkeid_hub -c $conf -p $port
