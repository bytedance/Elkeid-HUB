* You need to write your own INPUT.elkeid and OUTPUT.alert as needed
* Only for elkeid data: https://github.com/bytedance/Elkeid