#!/bin/sh

base_path=$(cd `dirname $0`; pwd)

cd $base_path

. pypy/bin/activate
export LD_LIBRARY_PATH=.
python3 -m gevent.monkey start.py >>./plugin.stdout 2>&1