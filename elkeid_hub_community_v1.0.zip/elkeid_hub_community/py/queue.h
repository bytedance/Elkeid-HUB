#ifndef ELKEID_PLUGIN_QUEUE_QUEUE_H
#define ELKEID_PLUGIN_QUEUE_QUEUE_H

#include <stddef.h>
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <sys/fcntl.h>
#include <sys/mman.h>

#define SHM_SIZE (1024 * 1024 * 128)

#define ELKEID_PAGE_SIZE  (1024 * 4)
#define ELKEID_HEADER_PAGE_COUNT  (16 + 4)

#define ELKEID_AVAILABLE_PAGE_COUNT  (1024 * 16)

#define ELKEID_MESSAGE_COUNT  (1024 * 8)

#define ELKEID_8_CLEAN (uint8_t)(0x00)
#define ELKEID_8_USED (uint8_t)(0xFF)

typedef struct {
    // msg queue 64K
    uint64_t msg_list[ELKEID_MESSAGE_COUNT];

    // page meta 16K
    uint8_t page_meta[ELKEID_AVAILABLE_PAGE_COUNT];
} elkeid_shm_file;

typedef struct {
    char *ptr;
    size_t size;
} elkeid_message;

typedef struct {
    elkeid_shm_file *file;
    uint32_t write_cursor;
    uint32_t read_cursor;

    uint32_t page_offset;
} elkeid_queue;

extern elkeid_queue *read_queue;
extern elkeid_queue *write_queue;

static inline elkeid_queue *elkeid_init_from_shm(const char *name) {
    elkeid_queue *queue;
    void *file_ptr;

    int fd = shm_open(name, O_CREAT | O_RDWR, 0);
    if (fd == -1) {
        perror("shm_open failed");
        exit(EXIT_FAILURE);
    }

    file_ptr = mmap(NULL, SHM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (file_ptr == (void *) -1) {
        perror("mmap failed");
        exit(EXIT_FAILURE);
    }

    queue = (elkeid_queue *) malloc(sizeof(elkeid_queue));
    queue->file = (elkeid_shm_file *) file_ptr;
    queue->page_offset = 0;
    queue->read_cursor = 0;
    queue->write_cursor = 0;
    return queue;
}

static inline uint32_t elkeid_ptr_to_page_offset(elkeid_queue *queue, const char *ptr) {
    uint32_t offset = (((uint64_t) ptr - (uint64_t) (queue->file)) / ELKEID_PAGE_SIZE) - ELKEID_HEADER_PAGE_COUNT;
    return offset;
}

static inline char *elkeid_page_offset_to_ptr(elkeid_queue *queue, uint32_t offset) {
    return (char *) (((size_t) queue->file) + ELKEID_PAGE_SIZE * (offset + ELKEID_HEADER_PAGE_COUNT));
}

static inline char *elkeid_write_ptr(elkeid_queue *queue) {
    return elkeid_page_offset_to_ptr(queue, queue->page_offset);
}

static inline void elkeid_write_submit(elkeid_queue *queue, size_t size) {
    uint32_t cursor = queue->write_cursor;
    uint32_t offset = queue->page_offset;

    uint32_t page_count = size / ELKEID_PAGE_SIZE + 1;
    for (uint32_t i = offset; i < offset + page_count && i < ELKEID_AVAILABLE_PAGE_COUNT; i++) {
        if (queue->file->page_meta[i] == ELKEID_8_CLEAN) {
            queue->file->page_meta[i] = ELKEID_8_USED;
        } else {
            // print error info
            printf("page_status2used_error: offset,%d page count,%d\n", i, page_count);
        }
    }

    queue->page_offset += page_count;
    if (queue->page_offset >= ELKEID_AVAILABLE_PAGE_COUNT) {
        queue->page_offset = 0;
    }

    queue->write_cursor = (cursor + 1) % ELKEID_MESSAGE_COUNT;

    __sync_synchronize();

    uint64_t info = (size << 32) + offset;
    queue->file->msg_list[cursor] = info;
}

static inline elkeid_message elkeid_read(elkeid_queue *queue) {
    elkeid_message message;
    message.ptr = NULL;
    message.size = 0;
    if (queue->file->msg_list[queue->read_cursor] == 0) {
        return message;
    }

    uint32_t cursor = queue->read_cursor;

    message.ptr = elkeid_page_offset_to_ptr(queue, queue->file->msg_list[cursor] | 0xFFFFFFFF00000000);
    message.size = queue->file->msg_list[cursor] >> 32;
    
    queue->file->msg_list[queue->read_cursor] = 0;
    queue->read_cursor = (cursor + 1) % ELKEID_MESSAGE_COUNT;
    return message;
}

static inline void elkeid_read_done(elkeid_queue *queue, const char *ptr, size_t size) {
    uint32_t page_count = size / ELKEID_PAGE_SIZE + 1;
    uint32_t offset = elkeid_ptr_to_page_offset(queue, ptr);

    for (uint32_t i = offset; i < offset + page_count && i < ELKEID_AVAILABLE_PAGE_COUNT; i++) {
        if (queue->file->page_meta[i] == ELKEID_8_USED) {
            queue->file->page_meta[i] = ELKEID_8_CLEAN;
        } else {
            // print error info
            printf("page_status2clean_error: offset,%d page count,%d\n", i, page_count);
        }
    }
}

static inline void queue_init() {
    if (read_queue != NULL && write_queue != NULL) {
        return;
    }
    char *read_shm_path = getenv("ELKEID_REQ_QUEUE_SHM_FILE");
    char *write_shm_path = getenv("ELKEID_RESP_QUEUE_SHM_FILE");

    read_queue = elkeid_init_from_shm(read_shm_path);
    write_queue = elkeid_init_from_shm(write_shm_path);
}

static inline elkeid_message queue_read() {
    return elkeid_read(read_queue);
}

static inline void queue_read_done(char *ptr, size_t size) {
    elkeid_read_done(read_queue, ptr, size);
}

static inline char *queue_write_ptr() {
    return elkeid_write_ptr(write_queue);
}

static inline void queue_submit(size_t size) {
    elkeid_write_submit(write_queue, size);
}

#endif //ELKEID_PLUGIN_QUEUE_QUEUE_H
