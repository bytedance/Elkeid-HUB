import importlib
from plugin_msgpack import unpackb
from msgpack import packb
from plugin_log import log

from cffi import FFI

ffi_builder = FFI()

ffi_builder.cdef("typedef struct {\nchar *ptr;\nsize_t size;\n} elkeid_message;")

ffi_builder.cdef(
    "void queue_init();\nelkeid_message queue_read();\nvoid queue_read_done(char *ptr, size_t size);\n"
    "char *queue_write_ptr();\nvoid queue_submit(size_t size);")

ffi_builder.set_source("_elkeid_queue", "#include \"queue.h\"\nelkeid_queue *read_queue;\nelkeid_queue *write_queue;",
                       extra_compile_args=["-std=c99"],
                       include_dirs=['.'],
                       libraries=['m', 'rt'])

ffi_builder.compile(verbose=True)

e = None
ffi = None


def queue_init():
    eq = importlib.import_module("_elkeid_queue")
    global e
    global ffi
    e = eq.lib
    ffi = eq.ffi
    e.queue_init()


def queue_read_req():
    msg = e.queue_read()
    if msg.size == 0:
        return None

    buffer = ffi.buffer(msg.ptr, msg.size)
    try:
        req = unpackb(bytes(buffer))
    except UnicodeDecodeError as err:
        log.error(str(msg.ptr) + ":" + str(msg.size))
        log.error(bytes(buffer))
        raise err
    finally:
        e.queue_read_done(msg.ptr, msg.size)

    return req


def queue_write_resp(resp):
    try:
        resp_data = packb(resp)
    except Exception as err:
        resp_copy = dict()
        resp_copy["req_id"] = resp["req_id"]
        resp_copy["err"] = repr(err)
        resp_data = packb(resp)

    char_data = ffi.from_buffer(resp_data)
    write_buffer = ffi.buffer(e.queue_write_ptr(), len(resp_data))

    ffi.memmove(write_buffer, char_data, len(resp_data))
    e.queue_submit(len(resp_data))
