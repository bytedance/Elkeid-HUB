import requests
import json
class Plugin(object):

    def __init__(self):
        self.name = None
        self.type = None
        self.log = None
        self.redis = None

    def plugin_exec(self, arg, config):
        token = "****"
        chat_id = "****"
        text=json.dumps(arg, ensure_ascii=False)
        url_req = "https://api.telegram.org/bot" + token + "/sendMessage" + "?chat_id=" + chat_id + "&text=" + text 
        #results = requests.get(url_req, proxies=proxies)
        results = requests.get(url_req)
        self.log.info(results.json())
        self.log.info(arg)
        self.log.info(config)
        result = dict()
        result["done"] = True
        return result

