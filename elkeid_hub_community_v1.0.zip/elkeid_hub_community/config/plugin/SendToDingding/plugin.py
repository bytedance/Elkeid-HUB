import json
import hashlib
import base64
import hmac
import os
import time
import requests
from urllib.parse import quote_plus


class Plugin(object):

    def __init__(self):
        self.name = None
        self.type = None
        self.log = None
        self.redis = None
        self.timestamp = str(round(time.time() * 1000))


    def plugin_exec(self, arg, config):
        self.log.info(arg)
        self.log.info(config)
        self.URL = "https://oapi.dingtalk.com/robot/send"
        secret="xxxxxxxxxxxxxxxx"
        token="xxxxxxxxxxxxxxxx"
        self.headers = {'Content-Type': 'application/json'}
        secret_enc = secret.encode('utf-8')
        string_to_sign = '{}\n{}'.format(self.timestamp, secret)
        string_to_sign_enc = string_to_sign.encode('utf-8')
        hmac_code = hmac.new(secret_enc, string_to_sign_enc, digestmod=hashlib.sha256).digest()
        self.log.info(hmac_code)
        self.sign = quote_plus(base64.b64encode(hmac_code))
        self.params = {'access_token': token, "sign": self.sign}
        self.log.info(self.params)
        data = {"msgtype": "text", "text": {"content": json.dumps(arg)}}
        self.params["timestamp"] = self.timestamp
        response =requests.post(
            url=self.URL,
            data=json.dumps(data),
            params=self.params,
            headers=self.headers
        )
        self.log.info(response.text)
        result = dict()
        result["done"] = True
        return result

