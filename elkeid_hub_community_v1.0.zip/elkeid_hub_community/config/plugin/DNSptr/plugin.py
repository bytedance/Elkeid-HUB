import json
import requests
class Plugin(object):

    def __init__(self):
        self.name = None
        self.type = None
        self.log = None
        self.redis = None
#https://www.nowapi.com/api/dns.ptr
    def plugin_exec(self, arg, config):
        self.log.info(arg)
        self.log.info(config)
        res=json.loads(arg)
        self.log.info(res['ip'])
        response=requests.get("http://api.k780.com/?app=dns.ptr&ip="+res['ip']+"&appkey=10003&sign=b59bc3ef6191eb9f747dd4e83c99f2a4&format=json")
        self.log.info(response.json())
        if(response.json()['success']=="1"):
            res["ptr"]=response.json()["result"]["ptr"]
            res["dns"]=response.json()["result"]["dns_server"]
        else:
            res["ptr"]="null"
        result = dict()
        result["flag"] = True
        result["msg"] = res
        self.log.info(result)
        return result

