import requests
import json
class Plugin(object):

    def __init__(self):
        self.name = None
        self.type = None
        self.log = None
        self.redis = None

    def plugin_exec(self, arg, config):
        headers = {
            'Content-Type': 'application/json',
        }
        params = (
            ('key', 'xxxxxxxxxx'),
        )
        data = {"msgtype": "text", "text": {"content": json.dumps(arg, ensure_ascii=False)}}
        response = requests.post('https://qyapi.weixin.qq.com/cgi-bin/webhook/send', headers=headers, params=params, data=json.dumps(data, ensure_ascii=False).encode())
        self.log.info(data)
        self.log.info(config)
        result = dict()
        result["done"] = True
        return result

